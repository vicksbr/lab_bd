REM INSERTING into DEPARTAMENTO
SET DEFINE OFF;
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('1','Engineering','Research and Development',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('2','Tool Design','Research and Development',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('3','Sales','Sales and Marketing',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('4','Marketing','Sales and Marketing',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('5','Purchasing','Inventory Management',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('6','Research and Development','Research and Development',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('7','Production','Manufacturing',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('8','Production Control','Manufacturing',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('9','Human Resources','Executive General and Administration',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('10','Finance','Executive General and Administration',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('11','Information Services','Executive General and Administration',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('12','Document Control','Quality Assurance',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('13','Quality Assurance','Quality Assurance',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('14','Facilities and Maintenance','Executive General and Administration',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('15','Shipping and Receiving','Inventory Management',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
Insert into DEPARTAMENTO (DEPARTAMENTO_ID,NOME,GRUPO,ULTIMA_MODIFICACAO) values ('16','Executive','Executive General and Administration',to_timestamp('14/03/16 14:54:52,000000000','DD/MM/RR HH24:MI:SSXFF'));
